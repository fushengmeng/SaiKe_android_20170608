package com.keruiyun.saike;

import android.widget.DatePicker;
import android.widget.NumberPicker;

public interface TimeSettingDialogActivityListener
{
	public void timeSettingDialogActivityDidSave(DatePicker dp, NumberPicker np1, NumberPicker np3, NumberPicker np4);
}
