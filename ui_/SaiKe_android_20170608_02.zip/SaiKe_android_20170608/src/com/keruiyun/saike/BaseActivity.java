package com.keruiyun.saike;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

import com.keruiyun.saike.controls.ProgressHUD;
import com.keruiyun.saike.util.Consts;

public class BaseActivity extends FragmentActivity {
	private ProgressHUD mProgressHUD;

	@Override
	protected void onCreate(Bundle arg0) {
		// TODO Auto-generated method stub
		super.onCreate(arg0);

	}

	protected void showToast(String content) {
		Toast.makeText(this, content, Toast.LENGTH_SHORT).show();
	}

	protected void showDialog() {
		if (null == mProgressHUD) {
			mProgressHUD = ProgressHUD.show(BaseActivity.this,
					getString(R.string.loading), true, false, null);
		} else {
			mProgressHUD.show();
		}
	}

	protected void closeDialog() {
		if (null != mProgressHUD) {
			mProgressHUD.dismiss();
		}
	}

	protected String getTimeStr(int length) {
		String str = "";
		int sec = length % 60;
		int minute = (length / 60) % 60;
		int hour = length / 3600;
		if (hour > 9) {
			str += String.valueOf(hour);
		} else {
			str += ("0" + String.valueOf(hour));
		}

		if (minute > 9) {
			str += (":" + String.valueOf(minute));
		} else {
			str += (":0" + String.valueOf(minute));
		}

		if (sec > 9) {
			str += (":" + String.valueOf(sec));
		} else {
			str += (":0" + String.valueOf(sec));
		}
		return str;
	}

	protected void displayStatusBar() {
		if (!Consts.IS_STATUS_BAR) {
			Intent intent = new Intent("com.android.action.display_statusbar");
			sendBroadcast(intent);
			Intent intent2 = new Intent(
					"com.android.action.display_navigationbar");
			sendBroadcast(intent2);
			Consts.IS_STATUS_BAR = true;
		}
	}

	protected void hideStatusBar() {
		if (Consts.IS_STATUS_BAR) {
			Intent intent = new Intent("com.android.action.hide_statusbar");
			sendBroadcast(intent);
			Intent intent2 = new Intent("com.android.action.hide_navigationbar");
			sendBroadcast(intent2);
			Consts.IS_STATUS_BAR = false;
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		hideStatusBar();
	}
}
