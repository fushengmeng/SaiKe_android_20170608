/*
 ============================================================================
 Name        : VideoCallFragmentListener.java
 Version     : 1.0.0
 Copyright   : www.keruiyun.com
 Description : 
 ============================================================================
 */

package com.keruiyun.saike;


public interface VideoCallFragmentListener
{
	public void onVideoCallSelect(String name, String number);
}
