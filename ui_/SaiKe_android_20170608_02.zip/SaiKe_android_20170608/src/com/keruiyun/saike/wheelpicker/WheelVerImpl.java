package com.keruiyun.saike.wheelpicker;

/**
 * Created by Administrator on 2016/7/1.
 */
class WheelVerImpl extends WheelDirection {
    WheelVerImpl(WheelPicker picker) {
        super(picker);
    }
}