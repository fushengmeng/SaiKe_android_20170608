package com.keruiyun.saike.wheelpicker;

/**
 * Created by Administrator on 2016/7/1.
 */
class WheelHorImpl extends WheelDirection {
    WheelHorImpl(WheelPicker picker) {
        super(picker);
    }
}