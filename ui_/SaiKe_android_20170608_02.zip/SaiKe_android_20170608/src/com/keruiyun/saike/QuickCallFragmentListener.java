/*
 ============================================================================
 Name        : ChatFragmentListener.java
 Version     : 1.0.0
 Copyright   : www.keruiyun.com
 Description : 
 ============================================================================
 */

package com.keruiyun.saike;


public interface QuickCallFragmentListener
{
	public void onQuickCallSelect(String number);
}
