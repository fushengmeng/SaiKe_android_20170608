package com.keruiyun.saike.model;


public class PeerModel
{
	public String ipAddress;
	public String name;
	public long timestamp;

}
