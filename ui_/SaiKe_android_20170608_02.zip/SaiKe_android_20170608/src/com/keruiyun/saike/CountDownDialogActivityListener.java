package com.keruiyun.saike;

import android.widget.NumberPicker;

public interface CountDownDialogActivityListener
{
	public void countDownDialogActivityDidSave(NumberPicker np1, NumberPicker np3, NumberPicker np4);
}
