package com.keruiyun.saike.serialservice;


public class SerialCommand 
{
	public byte[] cmd = new byte[128];
    public int len=0;
}
